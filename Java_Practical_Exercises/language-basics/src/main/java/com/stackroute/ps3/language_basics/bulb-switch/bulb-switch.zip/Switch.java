package com.stackroute.ps3.language_basics;

public interface Switch {
	void toggle();
	boolean getState();
}
